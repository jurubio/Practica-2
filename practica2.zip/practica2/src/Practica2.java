public class Practica2 {
    
}
